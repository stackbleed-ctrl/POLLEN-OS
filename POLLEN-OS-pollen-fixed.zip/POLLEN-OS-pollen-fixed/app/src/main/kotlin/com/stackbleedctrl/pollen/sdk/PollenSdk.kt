package com.stackbleedctrl.pollen.sdk

import com.stackbleedctrl.pollen.core.model.BrainDecision
import com.stackbleedctrl.pollen.oslayer.BrainEvent
import com.stackbleedctrl.pollen.oslayer.BrainEventBus
import com.stackbleedctrl.pollen.oslayer.PollenBrainService
import com.stackbleedctrl.pollen.swarm.SwarmCoordinator
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

@Singleton
class PollenSdk @Inject constructor(
    private val bus: BrainEventBus,
    private val swarm: SwarmCoordinator
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val brain = BrainHandle()

    inner class BrainHandle {
        private var decisionHandler: ((BrainDecision) -> Unit)? = null
        private var meshHandler: ((String) -> Unit)? = null

        fun handleDecision(block: (BrainDecision) -> Unit) {
            decisionHandler = block
        }

        fun handleMeshStatus(block: (String) -> Unit) {
            meshHandler = block
        }

        init {
            bus.events.onEach { event ->
                when (event) {
                    is BrainEvent.DecisionMade -> decisionHandler?.invoke(event.decision)
                    is BrainEvent.MeshStatus -> meshHandler?.invoke(event.text)
                    else -> Unit
                }
            }.launchIn(scope)
        }
    }

    suspend fun submitIntent(raw: String) {
        bus.emit(BrainEvent.InputEvent(com.stackbleedctrl.pollen.core.model.PhoneEvent.UserIntent(raw)))
    }

    suspend fun meshPing() {
        swarm.meshPing()
        bus.emit(BrainEvent.MeshStatus("Mesh ping sent"))
    }
}
